package databaseW12SH2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Ques2 {
	public static void main(String[] args) throws Exception {
		String url = "jdbc:mysql://localhost:3306/e";
		String uName = "root";
		String pass = "namansingla@123";

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uName, pass);
		Statement st = con.createStatement();
		st = con.createStatement();
		String query = "Insert Into employees values (001,'naman', 'singla', 90000, 50, 'naman@gmail.com', 'Yamunanagar')";
		st.executeUpdate(query);
		query = "Insert Into employees values (002,'Sohit', 'Kumar', 10000, 30, 'sohit@gmail.com', 'Chandigarh')";
		st.executeUpdate(query);
		query = "Insert Into employees values (003,'Mohit', 'Sharma', 80000, 10, 'mohits@gmail.com','Chandigarh')";
		st.executeUpdate(query);
		query = "Insert Into employees values (004,'Kapil', 'Verma', 70000, 20, 'kapil12@gmail.com', 'Delhi')";
		st.executeUpdate(query);
		query = "Insert Into employees values (005,'Aayan', 'Singh', 100000, 50, 'aayan@gmail.com', 'Mumbai')";
		st.executeUpdate(query);
		query = "Insert Into employees values (006,'Gudu', 'Khurana', 90000, 20, 'gudu@gmail.com','Mumbai')";
		st.executeUpdate(query);
		query = "Insert Into employees values (007,'Ankur', 'Gupta', 70000, 50, 'ankur@gmail.com','Kolkata')";
		st.executeUpdate(query);
		query = "Insert Into employees values (008,'Gopal', 'Garg', 80000, 20, 'gopalg@gmail.com', 'Delhi')";
		st.executeUpdate(query);
		query = "Insert Into employees values (009,'Maan', 'Sharma', 85000, 10, 'maan@gmail.com','Delhi')";
		st.executeUpdate(query);
		query = "Insert Into employees values (010,'Abhi', 'Prakash', 90000, 50, 'abhi@gmail.com','Yamunanagar')";
		st.executeUpdate(query);

		st.close();
		con.close();
	}
}
